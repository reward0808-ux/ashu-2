"use client"

import { useEffect, useState, useRef, useCallback } from "react"
import Image from "next/image"

// Logo piece configuration for the shattered effect
const logoPieces = [
  { id: 1, clipPath: "polygon(0% 0%, 33% 0%, 25% 50%, 0% 40%)", startX: -180, startY: -120, rotation: -45 },
  { id: 2, clipPath: "polygon(33% 0%, 66% 0%, 75% 30%, 50% 50%, 25% 50%)", startX: 0, startY: -200, rotation: 25 },
  { id: 3, clipPath: "polygon(66% 0%, 100% 0%, 100% 35%, 75% 30%)", startX: 200, startY: -100, rotation: 60 },
  { id: 4, clipPath: "polygon(0% 40%, 25% 50%, 30% 70%, 0% 100%)", startX: -220, startY: 50, rotation: -30 },
  { id: 5, clipPath: "polygon(25% 50%, 50% 50%, 55% 80%, 30% 70%)", startX: -80, startY: 180, rotation: 15 },
  { id: 6, clipPath: "polygon(50% 50%, 75% 30%, 100% 35%, 100% 65%, 70% 80%, 55% 80%)", startX: 150, startY: 100, rotation: -50 },
  { id: 7, clipPath: "polygon(0% 100%, 30% 70%, 55% 80%, 50% 100%)", startX: -100, startY: 220, rotation: 35 },
  { id: 8, clipPath: "polygon(50% 100%, 55% 80%, 70% 80%, 100% 65%, 100% 100%)", startX: 180, startY: 200, rotation: -40 },
]

// Particle configuration
interface Particle {
  id: number
  x: number
  y: number
  size: number
  color: string
  delay: number
  duration: number
}

export default function SplashScreen() {
  const [phase, setPhase] = useState<"floating" | "assembling" | "impact" | "glow" | "text">("floating")
  const [particles, setParticles] = useState<Particle[]>([])
  const audioRef = useRef<HTMLAudioElement | null>(null)
  const containerRef = useRef<HTMLDivElement>(null)

  // Generate particles
  useEffect(() => {
    const colors = ["#00F0FF", "#8B5CF6", "#FF008C", "#F8FAFC"]
    const newParticles: Particle[] = []
    for (let i = 0; i < 60; i++) {
      newParticles.push({
        id: i,
        x: Math.random() * 100,
        y: Math.random() * 100,
        size: Math.random() * 4 + 1,
        color: colors[Math.floor(Math.random() * colors.length)],
        delay: Math.random() * 5,
        duration: Math.random() * 3 + 4,
      })
    }
    setParticles(newParticles)
  }, [])

  // Play impact sound
  const playImpactSound = useCallback(() => {
    if (audioRef.current) {
      audioRef.current.currentTime = 0
      audioRef.current.play().catch(() => {})
    }
  }, [])

  // Animation sequence
  useEffect(() => {
    const timeline = [
      { phase: "floating" as const, delay: 0 },
      { phase: "assembling" as const, delay: 1500 },
      { phase: "impact" as const, delay: 3000 },
      { phase: "glow" as const, delay: 3500 },
      { phase: "text" as const, delay: 4200 },
    ]

    const timeouts: NodeJS.Timeout[] = []

    timeline.forEach(({ phase: p, delay }) => {
      const timeout = setTimeout(() => {
        setPhase(p)
        if (p === "impact") {
          playImpactSound()
        }
      }, delay)
      timeouts.push(timeout)
    })

    return () => timeouts.forEach(clearTimeout)
  }, [playImpactSound])

  return (
    <div
      ref={containerRef}
      className="relative w-full h-screen overflow-hidden flex items-center justify-center"
      style={{ 
        backgroundColor: "#060816",
        perspective: "1000px",
      }}
    >
      {/* Impact sound effect - using Web Audio API synthesis */}
      <audio
        ref={audioRef}
        src="data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdH2Onp+dm5uYloyDb3BzdH+HjI2KhoJ/fXp3dXZ4fIKIjY+OjImFgX16d3Z3en+FioqLioiGhIOAf35/gIKFiIqKioiGhIOBgICAgoWHiYqKiYeGhIOBgIGCg4WHiYqJiIeGhIOBgYKDhYaIiYmIh4aFg4KBgoOEhoiIiIiHhoWDgoKCg4WGiIiIh4eGhYSDgoKDhIWHiIiHhoaFhISDg4OEhYaHh4eHhoWEhIODg4SFhoaHh4eGhYWEg4OEhIWGhoeHhoaFhISDg4SEhYaGh4aGhYWEhIODhISFhoaGhoWFhISDg4SEhYWGhoaFhYSEg4ODhISFhYaGhYWEhIODg4SEhYWFhYWFhISDg4OEhIWFhYWFhISEg4ODhISEhYWFhYSEhIODg4OEhIWFhYWEhISEg4ODhISFhYWFhISEg4ODg4SEhYWFhISEhIODg4SEhIWFhYSEhIODg4OEhISFhYSEhISDg4ODhISEhYSEhISEg4ODg4SEhISEhISEg4ODg4OEhISEhISEg4ODg4OEhISEhISEg4ODg4OEhISEhISEg4ODg4OEhISEhISEg4ODg4OEhISEhISEg4ODg4OEhISEhISDg4ODg4OEhISEhISDg4ODg4OEhISEhISDg4ODg4ODhISEhISDg4ODg4ODhISEhISDg4ODg4ODhISEhISDg4ODg4ODhISEhISDg4ODg4ODg4SEhISDg4ODg4ODg4SEhISDg4ODg4ODg4SEhISDg4ODg4ODg4OEhISDg4ODg4ODg4OEhISDg4ODg4ODg4OEhISDg4ODg4ODg4OEhISDg4ODg4ODg4ODhISDg4ODg4ODg4ODhISDg4ODg4ODg4ODhISDg4ODg4ODg4ODg4SDg4ODg4ODg4ODg4SDg4ODg4ODg4ODg4SDg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4="
        preload="auto"
      />

      {/* Background floating particles */}
      <div className="absolute inset-0 overflow-hidden">
        {particles.map((particle) => (
          <div
            key={particle.id}
            className="absolute rounded-full"
            style={{
              left: `${particle.x}%`,
              top: `${particle.y}%`,
              width: particle.size,
              height: particle.size,
              backgroundColor: particle.color,
              boxShadow: `0 0 ${particle.size * 3}px ${particle.color}`,
              animation: `particle-float ${particle.duration}s ease-in-out infinite`,
              animationDelay: `${particle.delay}s`,
              opacity: 0.7,
            }}
          />
        ))}
      </div>

      {/* Energy waves background */}
      <div className="absolute inset-0 overflow-hidden opacity-30">
        {[...Array(3)].map((_, i) => (
          <div
            key={i}
            className="absolute inset-y-0 w-full"
            style={{
              background: `linear-gradient(90deg, transparent, ${i % 2 === 0 ? "#8B5CF6" : "#00F0FF"}20, transparent)`,
              animation: `energy-wave ${4 + i}s ease-in-out infinite`,
              animationDelay: `${i * 1.5}s`,
            }}
          />
        ))}
      </div>

      {/* Main container with camera shake effect */}
      <div
        className="relative z-10"
        style={{
          animation: phase === "impact" ? "camera-shake 0.5s ease-out" : "none",
        }}
      >
        {/* Shockwave effects */}
        {phase === "impact" && (
          <>
            {[...Array(3)].map((_, i) => (
              <div
                key={i}
                className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full pointer-events-none"
                style={{
                  width: 200,
                  height: 200,
                  border: `2px solid ${i === 0 ? "#00F0FF" : i === 1 ? "#8B5CF6" : "#FF008C"}`,
                  boxShadow: `0 0 30px ${i === 0 ? "#00F0FF" : i === 1 ? "#8B5CF6" : "#FF008C"}`,
                  animation: "shockwave 0.8s ease-out forwards",
                  animationDelay: `${i * 0.1}s`,
                }}
              />
            ))}
          </>
        )}

        {/* Light flash on impact */}
        {phase === "impact" && (
          <div
            className="fixed inset-0 pointer-events-none z-50"
            style={{
              background: "radial-gradient(circle at center, rgba(255,255,255,0.9) 0%, transparent 70%)",
              animation: "light-flash 0.4s ease-out forwards",
            }}
          />
        )}

        {/* Smoke effects */}
        {(phase === "impact" || phase === "glow" || phase === "text") && (
          <div className="absolute inset-0 pointer-events-none">
            {[...Array(6)].map((_, i) => (
              <div
                key={i}
                className="absolute top-1/2 left-1/2"
                style={{
                  width: 100 + i * 30,
                  height: 100 + i * 30,
                  marginLeft: -50 - i * 15 + (i % 2 === 0 ? 30 : -30),
                  marginTop: -50 - i * 15,
                  borderRadius: "50%",
                  background: `radial-gradient(circle, ${i % 2 === 0 ? "rgba(139, 92, 246, 0.3)" : "rgba(0, 240, 255, 0.2)"}, transparent)`,
                  animation: "smoke-rise 2s ease-out forwards",
                  animationDelay: `${i * 0.1}s`,
                }}
              />
            ))}
          </div>
        )}

        {/* Logo pieces - floating phase */}
        {(phase === "floating" || phase === "assembling") && (
          <div className="relative w-[280px] h-[280px]">
            {logoPieces.map((piece) => (
              <div
                key={piece.id}
                className="absolute inset-0"
                style={{
                  clipPath: piece.clipPath,
                  ["--start-x" as string]: `${piece.startX}px`,
                  ["--start-y" as string]: `${piece.startY}px`,
                  ["--start-rotation" as string]: `${piece.rotation}deg`,
                  transform:
                    phase === "floating"
                      ? `translate(${piece.startX}px, ${piece.startY}px) rotate(${piece.rotation}deg)`
                      : "translate(0, 0) rotate(0deg)",
                  animation:
                    phase === "floating"
                      ? `piece-float ${2 + (piece.id % 3) * 0.5}s ease-in-out infinite`
                      : phase === "assembling"
                        ? "assemble 1.2s cubic-bezier(0.34, 1.56, 0.64, 1) forwards"
                        : "none",
                  animationDelay: phase === "floating" ? `${piece.id * 0.2}s` : `${piece.id * 0.05}s`,
                  filter: "drop-shadow(0 0 15px #8B5CF6) drop-shadow(0 0 30px #00F0FF)",
                }}
              >
                <Image
                  src="/b2-battles-logo.png"
                  alt="B2 Battles Logo Piece"
                  width={280}
                  height={280}
                  className="w-full h-full object-contain"
                  priority
                />
              </div>
            ))}
          </div>
        )}

        {/* Complete logo - impact and glow phases */}
        {(phase === "impact" || phase === "glow" || phase === "text") && (
          <div
            className="relative"
            style={{
              animation:
                phase === "impact"
                  ? "impact-pop 0.6s cubic-bezier(0.34, 1.56, 0.64, 1) forwards, motion-blur-in 0.3s ease-out"
                  : phase === "glow" || phase === "text"
                    ? "logo-glow 2s ease-in-out infinite, electric-flicker 3s ease-in-out infinite"
                    : "none",
            }}
          >
            <Image
              src="/b2-battles-logo.png"
              alt="B2 Battles Logo"
              width={280}
              height={280}
              className="w-[280px] h-[280px] object-contain"
              priority
            />
          </div>
        )}

        {/* Electric sparks around logo */}
        {(phase === "glow" || phase === "text") && (
          <div className="absolute inset-0 pointer-events-none">
            {[...Array(12)].map((_, i) => {
              const angle = (i / 12) * Math.PI * 2
              const radius = 160
              return (
                <div
                  key={i}
                  className="absolute w-1 h-8 rounded-full"
                  style={{
                    left: `calc(50% + ${Math.cos(angle) * radius}px)`,
                    top: `calc(50% + ${Math.sin(angle) * radius}px)`,
                    background: `linear-gradient(to bottom, ${i % 3 === 0 ? "#00F0FF" : i % 3 === 1 ? "#8B5CF6" : "#FF008C"}, transparent)`,
                    transform: `rotate(${(angle * 180) / Math.PI + 90}deg)`,
                    boxShadow: `0 0 10px ${i % 3 === 0 ? "#00F0FF" : i % 3 === 1 ? "#8B5CF6" : "#FF008C"}`,
                    animation: `electric-flicker ${0.5 + Math.random() * 0.5}s ease-in-out infinite`,
                    animationDelay: `${i * 0.1}s`,
                    opacity: 0.8,
                  }}
                />
              )
            })}
          </div>
        )}
      </div>

      {/* "ENTER THE BATTLE" text */}
      {phase === "text" && (
        <div
          className="absolute bottom-[20%] left-1/2 -translate-x-1/2 text-center z-20"
          style={{
            animation: "text-glow-in 1s ease-out forwards",
          }}
        >
          <h2
            className="text-xl font-bold tracking-[0.3em] uppercase"
            style={{
              background: "linear-gradient(135deg, #00F0FF 0%, #8B5CF6 50%, #FF008C 100%)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              backgroundClip: "text",
              filter: "drop-shadow(0 0 10px rgba(139, 92, 246, 0.5))",
            }}
          >
            Enter The Battle
          </h2>
          
          {/* Animated underline */}
          <div
            className="mt-3 mx-auto h-[2px] rounded-full"
            style={{
              width: 0,
              background: "linear-gradient(90deg, transparent, #00F0FF, #8B5CF6, #FF008C, transparent)",
              animation: "expandLine 0.8s ease-out 0.3s forwards",
              boxShadow: "0 0 10px #8B5CF6, 0 0 20px #00F0FF",
            }}
          />
        </div>
      )}

      {/* Additional ambient glow */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: `
            radial-gradient(ellipse at 50% 50%, rgba(139, 92, 246, 0.15) 0%, transparent 50%),
            radial-gradient(ellipse at 30% 30%, rgba(0, 240, 255, 0.1) 0%, transparent 40%),
            radial-gradient(ellipse at 70% 70%, rgba(255, 0, 140, 0.1) 0%, transparent 40%)
          `,
        }}
      />

      <style jsx>{`
        @keyframes expandLine {
          0% {
            width: 0;
          }
          100% {
            width: 180px;
          }
        }
      `}</style>
    </div>
  )
}
